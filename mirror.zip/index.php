<html lang="en">
     <?php
 header("Access-Control-Allow-Origin: *");
    ?>
<head>
  <meta charset="utf-8">
  <title>jQuery.getJSON demo</title>
  <style>
  img {
    height: 100px;
    float: left;
  }
  </style>
  <script src="https://code.jquery.com/jquery-1.10.2.js"></script>
</head>
<body>
 
<div id="images"></div>
 
<script>
function getweather() {
  var apiCall = 'http://api.openweathermap.org/data/2.5/weather?q=Hyderabad&appid=a7689f15092d8a5c1185dedbf0d3b998';



$.getJSON(apiCall, weatherCallback);

function weatherCallback(weatherdata){
    console.log(weatherdata.main);
    //alert("data");
    //console.log("lol");
}
}
    
    //getweather();
</script>
    
<script>
    
    function getwiki(){
        var searchTerm = "saree";
        var wikiapicall = "https://en.wikipedia.org/w/api.php?action=opensearch&search="+ searchTerm +"&format=json&callback=?";
        
        $.getJSON(wikiapicall, wikicallback);
        
        function wikicallback(wikidata){
            console.log(wikidata);
            //alert ("wiki worked!");
        }
    }
    
    //getwiki();
    
</script>
    
<script>
    
    
    function getwolfram(){
$.ajax({
    type: "GET",
    url: "http://api.wolframalpha.com/v1/result?appid=G5XHT5-5EW648YL5Y&i=what%20is%20a%20saree",
    dataType: "xml",
    success: xmlParser
   });
};

function xmlParser(xml) {

    console.log(xmlParser);

}
    
    getwolfram();
    
</script>
 
</body>
</html>