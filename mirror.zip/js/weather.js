function getweather() {
  var apiCall = 'http://api.openweathermap.org/data/2.5/weather?q=Hyderabad&appid=a7689f15092d8a5c1185dedbf0d3b998';



$.getJSON(apiCall, weatherCallback);

function weatherCallback(weatherdata){
    console.log(weatherdata.main);
    //alert("the temperature is: " + weatherdata.main.temp);
    //console.log("lol");
}
}
    
getweather();