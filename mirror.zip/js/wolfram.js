function getwolfram(input){
        var wolframapicall = "http://api.wolframalpha.com/v1/spoken?appid=G5XHT5-5EW648YL5Y&i=" + input + "&units=metric";
        
        $.get(wolframapicall, wolframcallback);
        
        function wolframcallback(wolframans){
            console.log("success");
            console.log(wolframans);
        }
        
    
}


    
getwolfram("define information");
    