function getwiki(input){
       
        var wikiapicall = "https://en.wikipedia.org/w/api.php?action=opensearch&search="+ input +"&format=json&callback=?";
        
        $.getJSON(wikiapicall, wikicallback);
        
        function wikicallback(wikidata){
            console.log(wikidata);
            //alert (wikidata);
        }
}
    
getwiki("kore");